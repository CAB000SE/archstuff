# Stack

This plugin provides completion for [Stack](https://haskellstack.org).

To use it add stack to the plugins array in your zshrc file.

```bash
plugins=(... stack)
```
